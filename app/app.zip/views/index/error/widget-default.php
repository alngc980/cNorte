<link rel="stylesheet" href="./res/css/index.css">
<body class="" style="background: white;">
      <?php  require_once _VIEW_PATH_ . 'nav-index.php'; ?>
      <div class="t-body" data-simplebar>
    <div class="contenedor">
        <div class="fila">
            <div class="c-12 f-12 f-24-m center center-y">
                <div class="c-12 f-10 f-20-m imagen-error">
                </div>
                <div class="c-3 f-2  f-4-m center"><a href="index.php"class="boton primario-w">Regresar</a></div>
            </div>
        </div>
    </div>
    
</div>
       

    </body>
