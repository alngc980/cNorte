<footer class="py-5" id="footer-main">
	<div class="container">
		<div class="row align-items-center justify-content-xl-between">
			<div class="col-xl-6">
				<div class="copyright text-center text-xl-left text-orange">
					&copy; 2021 SITISAFE
				</div>
			</div>
		
		</div>
	</div>
</footer>