<div class="col-xl-12 order-xl-2">
    <div class="card">
        <div class="card-header">
        </div>
        <div class="card-body">
            <img style="  max-width: 100%;height: auto;" src="./res/img/notfount404.png">
        </div>
    </div>
</div>