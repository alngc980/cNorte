<div class="col">
  <div class="row">
   
  </div>
  <a href="#notifica" id="link"></a>
  <div id="notifica">

  </div>

  <div class="card">
    <!-- Card header -->
    <div class="card-header border-0">
      <h3 class="mb-0">Lista de usuarios</h3>
    </div>

    <!-- Light table -->
    <div class="table-responsive">

      <table class="table align-items-center table-flush">
        <thead class="thead-light">
          <tr>
            <th scope="col" class="sort" data-sort="name">Nombres</th>
            <th scope="col" class="sort" data-sort="budget">Apellidos</th>
            <th scope="col" class="sort" data-sort="status">Tipo Usuario</th>
            <th scope="col">Estado</th>
            <th scope="col"></th>
          </tr>
        </thead>
        <tbody class="list" id="tbluser">
        </tbody>
      </table>
    </div>
  </div>
</div>
<script src="res/dtgsk/js/user/index.js"></script>